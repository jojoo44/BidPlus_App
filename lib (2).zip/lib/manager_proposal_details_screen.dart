// manager_proposal_details_screen.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../main.dart';
import 'contractor_profile_screen.dart';

class ManagerProposalDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> proposal;
  final VoidCallback onStatusChanged;

  const ManagerProposalDetailsScreen({
    super.key,
    required this.proposal,
    required this.onStatusChanged,
  });

  @override
  State<ManagerProposalDetailsScreen> createState() =>
      _ManagerProposalDetailsScreenState();
}

class _ManagerProposalDetailsScreenState
    extends State<ManagerProposalDetailsScreen> {
  late String _status;
  bool _isLoading = false;
  List<Map<String, dynamic>> _documents = [];
  bool _loadingDocs = true;

  static const bg = Color(0xFF0D1219);
  static const card = Color(0xFF1C242F);
  static const stroke = Color(0xFF22314A);
  static const blue = Color(0xFF3395FF);

  @override
  void initState() {
    super.initState();
    _status = widget.proposal['status'] ?? 'Submitted';
    _loadDocuments();
  }

  Future<void> _loadDocuments() async {
    try {
      final proposalId = widget.proposal['ProposalID'];
      if (proposalId == null) {
        setState(() => _loadingDocs = false);
        return;
      }
      final data = await supabase
          .from('Document')
          .select('*')
          .eq('proposalID', proposalId)
          .order('uploadDate', ascending: false);

      if (mounted) {
        setState(() {
          _documents = List<Map<String, dynamic>>.from(data);
          _loadingDocs = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading documents: $e');
      if (mounted) setState(() => _loadingDocs = false);
    }
  }

  void _openContractorProfile() {
    final contractorId = widget.proposal['submitterUserId'];
    if (contractorId == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ContractorProfileScreen(contractorId: contractorId),
      ),
    );
  }

  Future<void> _openFile(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cannot open file')),
        );
      }
    }
  }

  Future<void> _updateStatus(String newStatus) async {
    setState(() => _isLoading = true);
    try {
      final proposalId = widget.proposal['ProposalID'];
      final contractorId = widget.proposal['submitterUserId'];
      final rfp = widget.proposal['RFP'] as Map<String, dynamic>? ?? {};
      final rfpId = rfp['rfpID'] ?? widget.proposal['RFP'];

      await supabase
          .from('proposals')
          .update({'status': newStatus})
          .eq('ProposalID', proposalId);

      // ── FIX: استخدام maybeSingle() بدل single() لتجنب خطأ 406 ──
      if (newStatus == 'Accepted' && rfpId != null) {
        final existing = await supabase
            .from('NegoSession')
            .select('session_id')
            .eq('rfp_id', rfpId.toString())
            .maybeSingle();

        if (existing == null) {
          await supabase.from('NegoSession').insert({
            'status': 'Active',
            'start_date': DateTime.now().toIso8601String(),
            'rfp_id': rfpId.toString(),
          });
        }
      }

      if (contractorId != null) {
        // ── FIX: maybeSingle() بدل single() لتجنب 406 عند تعدد الصفوف ──
        final contractorData = await supabase
            .from('User')
            .select('notificationsEnabled')
            .eq('id', contractorId)
            .limit(1)
            .maybeSingle();

        if (contractorData != null &&
            contractorData['notificationsEnabled'] != false) {
          final rfpTitle = rfp['title'] ?? 'a project';
          String message;
          if (newStatus == 'Accepted') {
            message =
                'Your proposal for "$rfpTitle" has been accepted! Negotiation has started.';
          } else if (newStatus == 'Rejected') {
            message =
                'Your proposal for "$rfpTitle" was not selected this time.';
          } else {
            message = 'Your proposal for "$rfpTitle" is now under review.';
          }

          await supabase.from('Notification').insert({
            'userID': contractorId,
            'type': newStatus,
            'message': message,
            'readStatus': false,
            'timeStamp': DateTime.now().toIso8601String(),
          });
        }
      }

      setState(() => _status = newStatus);
      widget.onStatusChanged();

      if (mounted) {
        // ── ألوان الـ Snackbar حسب الحالة ──
        Color snackColor;
        String snackMsg;
        if (newStatus == 'Accepted') {
          snackColor = Colors.green;
          snackMsg = '✅ Proposal accepted & negotiation started!';
        } else if (newStatus == 'Rejected') {
          snackColor = Colors.red;
          snackMsg = '❌ Proposal rejected.';
        } else if (newStatus == 'Submitted') {
          snackColor = blue;
          snackMsg = '🔄 Proposal reset to Submitted';
        } else {
          snackColor = blue;
          snackMsg = 'Proposal updated to $newStatus';
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              snackMsg,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
            backgroundColor: snackColor,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Color _statusColor(String s) {
    switch (s.toLowerCase()) {
      case 'accepted':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      case 'under review':
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  IconData _statusIcon(String s) {
    switch (s.toLowerCase()) {
      case 'accepted':
        return Icons.check_circle;
      case 'rejected':
        return Icons.cancel;
      case 'under review':
        return Icons.hourglass_top;
      default:
        return Icons.hourglass_empty;
    }
  }

  IconData _fileIcon(String? uploadType) {
    switch ((uploadType ?? '').toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'image':
        return Icons.image;
      case 'word':
        return Icons.description;
      case 'excel':
        return Icons.table_chart;
      default:
        return Icons.insert_drive_file;
    }
  }

  Color _fileColor(String? uploadType) {
    switch ((uploadType ?? '').toLowerCase()) {
      case 'pdf':
        return Colors.red;
      case 'image':
        return Colors.blue;
      case 'word':
        return Colors.blueAccent;
      case 'excel':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final rfp = widget.proposal['RFP'] as Map<String, dynamic>? ?? {};
    final name = widget.proposal['contractorname'] ?? 'Unknown';
    final price = widget.proposal['proposedPrice']?.toString() ?? '—';
    final date = widget.proposal['submitDate'] ?? '—';
    final desc = widget.proposal['description'] ?? '';
    final comments = widget.proposal['comments'] ?? '';

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        title: const Text(
          'Proposal Details',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── FIX: Status Banner - إصلاح الـ Overflow ──
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _statusColor(_status).withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _statusColor(_status).withOpacity(0.3),
                ),
              ),
              child: _status.toLowerCase() == 'accepted'
                  // ── إذا accepted: عمود بدل Row لتجنب الـ overflow ──
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              _statusIcon(_status),
                              color: _statusColor(_status),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'Status: $_status',
                              style: TextStyle(
                                color: _statusColor(_status),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.purple.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.purple.withOpacity(0.4),
                            ),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.handshake_outlined,
                                color: Colors.purple,
                                size: 14,
                              ),
                              SizedBox(width: 4),
                              Text(
                                'Negotiation Active',
                                style: TextStyle(
                                  color: Colors.purple,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    )
                  // ── باقي الحالات: Row عادي ──
                  : Row(
                      children: [
                        Icon(
                          _statusIcon(_status),
                          color: _statusColor(_status),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'Status: $_status',
                          style: TextStyle(
                            color: _statusColor(_status),
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
            ),

            const SizedBox(height: 20),

            // Contractor Info
            _sectionTitle('Contractor Info'),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: stroke),
              ),
              child: Column(
                children: [
                  _row(Icons.person, 'Name', name),
                  _row(Icons.attach_money, 'Proposed Price', '$price SAR'),
                  _row(Icons.send, 'Submitted On', date),
                  const Divider(color: Color(0xFF22314A), height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: blue),
                        foregroundColor: blue,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: _openContractorProfile,
                      icon: const Icon(Icons.person_outline, size: 16),
                      label: const Text(
                        'View Profile',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Project Info
            _sectionTitle('Project Info'),
            _infoCard([
              _row(Icons.title, 'Project', rfp['title'] ?? '—'),
              _row(Icons.calendar_today, 'Deadline', rfp['deadline'] ?? '—'),
              _row(
                Icons.attach_money,
                'Budget',
                rfp['budget'] != null ? '${rfp['budget']} SAR' : '—',
              ),
            ]),

            const SizedBox(height: 16),

            // Submitted Documents
            _sectionTitle('Submitted Documents'),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: stroke),
              ),
              child: _loadingDocs
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: CircularProgressIndicator(color: blue),
                      ),
                    )
                  : _documents.isEmpty
                  ? const Row(
                      children: [
                        Icon(Icons.folder_open, color: Colors.grey, size: 20),
                        SizedBox(width: 10),
                        Text(
                          'No documents submitted',
                          style: TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                      ],
                    )
                  : Column(
                      children: _documents.map((doc) {
                        final fileName = doc['fullName'] ?? 'Unnamed File';
                        final fileUrl = doc['fileURL'] ?? '';
                        final uploadType = doc['uploadType'];
                        final uploadDate = doc['uploadDate'] ?? '';

                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0D1219),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: stroke),
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: _fileColor(uploadType).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  _fileIcon(uploadType),
                                  color: _fileColor(uploadType),
                                  size: 20,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      fileName,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    if (uploadDate.isNotEmpty)
                                      Text(
                                        uploadDate,
                                        style: const TextStyle(
                                          color: Colors.grey,
                                          fontSize: 11,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              IconButton(
                                onPressed: fileUrl.isNotEmpty
                                    ? () => _openFile(fileUrl)
                                    : null,
                                icon: const Icon(
                                  Icons.open_in_new,
                                  color: blue,
                                  size: 20,
                                ),
                                tooltip: 'Open File',
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
            ),

            const SizedBox(height: 16),

            // Cover Letter
            if (desc.isNotEmpty) ...[
              _sectionTitle('Cover Letter'),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: stroke),
                ),
                child: Text(
                  desc,
                  style: const TextStyle(
                    color: Colors.white70,
                    height: 1.6,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Evaluation Criteria Responses
            if (comments.isNotEmpty) ...[
              _sectionTitle('Evaluation Criteria Responses'),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: stroke),
                ),
                child: Column(
                  children: comments.toString().split('|').map<Widget>((part) {
                    final trimmed = part.trim();
                    final colonIdx = trimmed.indexOf(':');
                    if (colonIdx == -1) return const SizedBox.shrink();
                    final label = trimmed.substring(0, colonIdx).trim();
                    final value = trimmed.substring(colonIdx + 1).trim();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.blue.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              label,
                              style: const TextStyle(
                                color: Colors.blue,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              value,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 16),
            ],

            const SizedBox(height: 16),

            // Action Buttons
            if (_status.toLowerCase() != 'accepted' &&
                _status.toLowerCase() != 'rejected') ...[
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: _isLoading
                          ? null
                          : () => _updateStatus('Accepted'),
                      icon: const Icon(Icons.check_circle, color: Colors.white),
                      label: const Text(
                        'Accept',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: _isLoading
                          ? null
                          : () => _updateStatus('Rejected'),
                      icon: const Icon(Icons.cancel, color: Colors.white),
                      label: const Text(
                        'Reject',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.blue),
                    foregroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _isLoading
                      ? null
                      : () => _updateStatus('Under Review'),
                  icon: const Icon(Icons.hourglass_top),
                  label: const Text(
                    'Under Review',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ] else ...[
              // ── FIX: زر Reset to Submitted - لون أزرق جميل ──
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: blue.withOpacity(0.15),
                    foregroundColor: blue,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: blue.withOpacity(0.5)),
                    ),
                    elevation: 0,
                  ),
                  onPressed: _isLoading ? null : () => _updateStatus('Submitted'),
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text(
                    'Reset to Submitted',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
              ),
            ],

            if (_isLoading)
              const Padding(
                padding: EdgeInsets.only(top: 16),
                child: Center(child: CircularProgressIndicator()),
              ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(
      t,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 15,
        fontWeight: FontWeight.w700,
      ),
    ),
  );

  Widget _infoCard(List<Widget> rows) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: card,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: stroke),
    ),
    child: Column(children: rows),
  );

  Widget _row(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      children: [
        Icon(icon, color: Colors.white54, size: 16),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
        const Spacer(),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ],
    ),
  );
}